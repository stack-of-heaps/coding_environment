#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP

#include "character.hpp"

class Barbarian : public Character {

    public: 
        Barbarian(std::string n);

//        int attack();
 //       int defend(int attack);

};

#endif
