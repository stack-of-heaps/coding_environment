
#include "menu.hpp"

int main(){

/*
Barbarian b = Barbarian("Steve");
Barbarian c = Barbarian("Charlie");

Vampire v = Vampire("Boo");

int attackVal = b.attack();
b.defend(attackVal);

attackVal = v.attack();
v.defend(attackVal);
*/

    setupMatch();

    return 0;
}
