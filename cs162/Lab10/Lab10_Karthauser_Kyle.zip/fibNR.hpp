#ifndef FIBNR_HPP
#define FIBNR_HPP

int fibNRCalc(int n);

#endif
