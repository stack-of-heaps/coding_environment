#ifndef FIBR_HPP
#define FIBR_HPP

#include <iostream>


/**************************************************************
 *
 * Implementation based on: 
 * https://www.codeproject.com/tips/109443/fibonacci-recursive-and-non-recursive-c
 * ***********************************************************/

int fibRCalc(int n);

#endif
