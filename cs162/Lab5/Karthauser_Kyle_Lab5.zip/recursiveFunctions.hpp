#ifndef RECURSIVEFUNCTIONS_HPP
#define RECURSIVEFUNCTIONS_HPP

#include <string>

void stringInReverse(std::string userString);

int sumOfArray(int* array, int arrayNums);

int triangleNumber(int userInput);

#endif
