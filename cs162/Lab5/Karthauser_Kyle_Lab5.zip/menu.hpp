#ifndef MENU_HPP
#define MENU_HPP

int menu(int choice);

#endif
