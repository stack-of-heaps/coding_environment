#include "menu.hpp"
#include "recursiveFunctions.hpp"
#include <iostream>

int main(){

int keepRunning = 0;

while (keepRunning != -1) 
    keepRunning = menu(5);

    return 0;
}
