#include "yomu.hpp"
#include "menu.hpp"

int main() {

bool keepRunning = true;

while (keepRunning) {
    dispMenu();

}

return 0;
}

/*
    nodeList -> addToHead(1);

    nodeList -> display();
    
    nodeList -> addToTail(-2);
    nodeList -> display();
    nodeList -> addToHead(3);
    nodeList -> display();
    nodeList -> addToTail(-4);
    nodeList -> display();

    nodeList -> addToHead(5);

    nodeList -> display();

    nodeList -> addToHead(3);

    nodeList -> display();

    nodeList -> deleteFirstNode();

    nodeList -> display();

    nodeList -> deleteLastNode();

    nodeList -> display();
*/


