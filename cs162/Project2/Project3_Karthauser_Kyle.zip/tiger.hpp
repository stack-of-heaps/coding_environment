#ifndef TIGER_HPP
#define TIGER_HPP

#include "animal.hpp"

class Tiger : public Animal {

    public:
        Tiger(); // Animal();
        Tiger(int a); // Animal();
};

#endif
