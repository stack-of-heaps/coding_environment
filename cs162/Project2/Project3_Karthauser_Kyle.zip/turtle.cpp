#include "turtle.hpp"

Turtle::Turtle() : Animal(0, 100, 10, .05, .5, 1) {};
Turtle::Turtle(int a) : Animal(3, 100, 10, .05, .5, 1) {};
