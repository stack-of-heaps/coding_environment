#include "penguin.hpp"

Penguin::Penguin() : Animal(0, 1000, 5, 1, 1, .1) {};

Penguin::Penguin(int a) : Animal(3, 1000, 5, 1, 1, .1) {};

