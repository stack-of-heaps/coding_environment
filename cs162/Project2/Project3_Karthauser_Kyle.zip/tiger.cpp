#include "tiger.hpp"

Tiger::Tiger() : Animal(0, 10000, 1, 5, 1, .2) {};

Tiger::Tiger(int a) : Animal(3, 10000, 1, 5, 1, .2) {};

