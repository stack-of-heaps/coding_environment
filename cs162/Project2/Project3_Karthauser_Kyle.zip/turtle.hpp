#ifndef TURTLE_HPP
#define TURTLE_HPP

#include "animal.hpp"

class Turtle : public Animal {

    public:
        Turtle(); // Animal();
        Turtle(int a); // Animal();
};

#endif
