#include "zoo.hpp"

int main() {

Zoo zoo;

zoo.setup();

zoo.run();

    return 0;
}
