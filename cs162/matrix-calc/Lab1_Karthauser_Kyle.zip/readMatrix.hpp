#ifndef READMATRIX_HPP
#define READMATRIX_HPP

void readMatrix(int** array, int arraySize);

#endif
