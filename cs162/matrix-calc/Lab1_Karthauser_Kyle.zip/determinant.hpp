#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

#include <iostream>

int determinant(int** array, int arraySize);

#endif
