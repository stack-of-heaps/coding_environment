#ifndef ANT_HPP
#define ANT_HPP

#include "critter.hpp"

class Ant : public Critter
{
private:


public:

void move(int rows, int columns, Critter*** gameBoardPtr, int numberOfRows, int numberOfColumns);

};


#endif
