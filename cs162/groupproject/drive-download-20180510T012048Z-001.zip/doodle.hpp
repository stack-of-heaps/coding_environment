#ifndef DOODLE_HPP
#define DOODLE_HPP

#include "critter.hpp"

class Doodle : public Critter{

public:
    void move(int rows, int columns, Critter*** gameBoardPtr, int numberOfRows, int numberOfColumns);


};

#endif // ANT_HPP
