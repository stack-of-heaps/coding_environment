#ifndef MENU_HPP
#define MENU_HPP

int menu();

#endif
