#include "board.hpp"
#include "ant.hpp"
#include "menu.hpp"

#include <iostream>


int main(){

    menu();

    return 0;
}
