#ifndef YOMU_HPP
#define YOMU_HPP

#include <string>
#include <sstream>

int yomu(const std::string& input);

#endif
