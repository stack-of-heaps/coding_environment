#include "menu.hpp"

int main() {

    bool keepRunning = true;
    while (keepRunning)
        keepRunning = dispMenu();

    return 0;

}
