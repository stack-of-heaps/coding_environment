#include "menu.hpp"

int main() {

    bool keepRunning = true;

    while (keepRunning) 
    keepRunning = init();

    return 0;
}
