#ifndef STACK_HPP
#define STACK_HPP

#include <stack>
#include <string>

void palindromer(std::string theString);


#endif
