#ifndef MENU_HPP
#define MENU_HPP

bool init();
void runBuffer();
void runStack();
double averageLength(int steps, int size);

#endif
