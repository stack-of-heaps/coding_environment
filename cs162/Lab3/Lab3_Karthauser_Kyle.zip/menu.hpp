#ifndef MENU_HPP
#define MENU_HPP
#include "yomu.hpp"
#include "die.hpp"
#include "loadedDie.hpp"

#include <vector>

int menu();

int menuChooseDieType(int playerNumber);

int menuHowManyRounds();

#endif
